IMMIGRANTROOTS WEBSITE
======================

This folder is the complete website. It has no build step.
  index.html          the main site (design, English + Kreyòl + Spanish, animations)
  privacy.html        Privacy Policy (all three languages)
  accessibility.html  Accessibility Statement (all three languages)
  logo-square.jpg     logo used in the navbar, footer, and browser tab
  logo-full.jpg       big logo used on the welcome screen and link previews
  robots.txt          tells search engines they may list the site
  sitemap.xml         list of the site's pages for Google

PUT IT ONLINE (GitHub + Vercel)
1. github.com > sign up or log in > New repository > name it "immigrantroots-site" > Create.
2. Click "uploading an existing file". Drag in ALL the files above. Click "Commit changes".
3. vercel.com > Add New > Project > Import the "immigrantroots-site" repo.
   Framework Preset: Other. Leave build settings empty. Click Deploy.
4. In the new project: Settings > Domains > add immigrantroots.com
   and www.immigrantroots.com.
5. Optional: add the site in Google Search Console
   (search.google.com/search-console) and submit sitemap.xml so Google
   finds it faster.

TURN ON THE FORMS
The waitlist and contact forms send to hello@immigrantroots.com through
FormSubmit (free). Set up that email address first. After the site is live,
submit the waitlist form once yourself. FormSubmit emails an activation link
to hello@immigrantroots.com. Click it. From then on, every signup arrives
in that inbox.

MAKING CHANGES LATER
Edit a file on GitHub (pencil icon) and commit. Vercel republishes in
about a minute.
  - Main site text for all languages: in index.html, search for "var COPY".
  - Languages on the welcome circle: in index.html, search for "var LANGS".
  - Form email: in index.html, search for "FORM_ENDPOINT".
  - Policy text: in privacy.html or accessibility.html, search for "var D".
    If you change the policies, also change the "Last updated" date.
